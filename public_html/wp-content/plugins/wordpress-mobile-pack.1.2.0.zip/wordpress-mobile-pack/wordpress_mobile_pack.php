<?php
 //This empty file is for legacy compatibility.
 //The plugin is found in the neighbouring file wordpress-mobile-pack.php.
 //And in fact, you should even be able to delete this file now.
?>
