Copyright (C) 2005 Paul J. Armstrong
paul@paularmstrongdesigns.com
http://paularmstrongdesigns.com

To get the original .psd files for the icons, please visit 
http://paularmstrongdesigns.com or email paul@paularmstrongdesigns.com

These icons are free; you may redistribute and or modify them under the terms of
the GNU General Public License as published by the Free Software Foundation; 
either version 2 of the License, or (at your option) any later version.

To get a copy of the GNU General Public License, write to the Free Software
Foundation, Inc., 51 Franklin Street - Fifth Floor, Boston, MA  02110-1301, USA.
